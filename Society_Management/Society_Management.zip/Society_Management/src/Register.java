import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.io.*;
/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstname = request.getParameter("user_firstname");
		String lastname = request.getParameter("user_lastname");
		Long mobileno = Long.parseLong(request.getParameter("user_mobileno"));
		String email = request.getParameter("user_email");
		String password = request.getParameter("user_password");
		String confirmpassword = request.getParameter("user_confirmpassword");
		String birthdate = request.getParameter("user_birthdate");
		String flatpuchasedate = request.getParameter("user_flatpurchasedate");
		String flatblock = request.getParameter("user_flatblock");
		int flatnumber = Integer.parseInt(request.getParameter("user_flatnumber"));

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/society_management","root","root");
	
			PreparedStatement stmt = con.prepareStatement("INSERT INTO register(first_name, last_name, mobile_no, email, password, confirm_password, birthdate, flat_purchase_date, flat_block, flat_number) VALUES(?,?,?,?,?,?,?,?,?,?)");
	
			stmt.setString(1, firstname);
			stmt.setString(2, lastname);
			stmt.setLong(3, mobileno);
			stmt.setString(4, email);
			stmt.setString(5, password);
			stmt.setString(6, confirmpassword);
			stmt.setString(7, birthdate);
			stmt.setString(8, flatpuchasedate);
			stmt.setString(9, flatblock);
			stmt.setInt(10, flatnumber);
	
			int i = stmt.executeUpdate();
			if(i>0){
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("<center><h3>Successfully Registered...</h3></center><br>");
				out.println("<center><a href='loginform.jsp'>Click here to Login...</a><center>");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
