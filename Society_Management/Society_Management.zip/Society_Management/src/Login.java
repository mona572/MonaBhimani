import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;
import java.io.*;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String loginemail = request.getParameter("user_login_email");
		String loginpassword = request.getParameter("user_login_password");

		try {
			
			HttpSession session=request.getSession();  
	        session.setAttribute("login_email",loginemail); 
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/society_management","root","root");
			Statement stmt = con.createStatement();
	
			ResultSet rs = stmt.executeQuery("SELECT * FROM register WHERE email='"+loginemail+"' AND password='"+loginpassword+"'");
	
			if(rs.next()){
				response.sendRedirect("welcome.jsp");
			}
			else{
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("<center><h3>Invalid credentials...</h3></center><br>");
				out.println("<center><a href='loginform.jsp'>Please login again...</a><center>");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
